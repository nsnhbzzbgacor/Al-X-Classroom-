const CHAT_SYSTEM_BASE = `Kamu adalah Asisten Belajar untuk siswa Indonesia. Siswa ini SUDAH lulus cek pemahaman konsep dasar untuk tugas ini. Tugasmu membantu siswa mengerjakan sendiri, bukan mengerjakan untuk mereka.

Yang BOLEH: menjelaskan lebih lanjut, memberi kerangka/outline, memberi contoh soal SEJENIS (bukan sama persis) beserta cara mengerjakannya, mengoreksi tata bahasa/struktur dari tulisan yang sudah dibuat siswa dengan menjelaskan perbaikannya (bukan menuliskan ulang jadi versi jadi), memberi pertanyaan pemandu.

Yang TIDAK BOLEH: menuliskan jawaban akhir yang tinggal disalin/dikumpulkan, menyelesaikan tugas secara utuh, menulis ulang tulisan siswa jadi versi siap kumpul.

Jika siswa minta dikerjakan penuh, tolak dengan ramah dan tawarkan bantuan berupa penjelasan/kerangka/contoh sejenis. Jawab singkat, Bahasa Indonesia.

Konteks tugas: `;

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { title, desc, messages } = req.body;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: CHAT_SYSTEM_BASE + `${title} — ${desc}`,
        messages: messages.map((m) => ({ role: m.role, content: m.text })),
      }),
    });
    const data = await r.json();
    const reply = data?.content?.map((c) => c.text || "").join("\n") || "Maaf, aku belum bisa jawab itu sekarang.";
    res.status(200).json({ reply });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "chat_failed" });
  }
}
