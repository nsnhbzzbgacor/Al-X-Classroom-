const QUIZ_SYSTEM = `Kamu membuat soal cek pemahaman singkat. Balas HANYA dalam format JSON murni, tanpa teks lain, tanpa markdown, tanpa backtick.
Format: {"questions":[{"question":"...","options":["A","B","C","D"],"correctIndex":0}, ...]}
Buat TEPAT 3 soal pilihan ganda dasar (level SMA) tentang KONSEP di balik topik tugas berikut, bukan soal identik dengan tugasnya. Fokus pada konsep dasar yang wajib dipahami sebelum bisa mengerjakan tugas itu.`;

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { title, desc } = req.body;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: QUIZ_SYSTEM,
        messages: [{ role: "user", content: `Judul tugas: ${title}\nDeskripsi: ${desc}` }],
      }),
    });
    const data = await r.json();
    const text = data?.content?.map((c) => c.text || "").join("\n") || "";
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    res.status(200).json(parsed);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "quiz_generation_failed" });
  }
}
