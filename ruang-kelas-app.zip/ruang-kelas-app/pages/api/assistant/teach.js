const TEACH_SYSTEM = `Kamu adalah guru yang menjelaskan konsep dasar ke siswa SMA yang baru saja gagal cek pemahaman. Jelaskan konsep dasar topik yang diberikan dengan bahasa sederhana, pakai contoh konkret, maksimal 180 kata. Akhiri dengan ajakan mencoba cek pemahaman lagi. Bahasa Indonesia.`;

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { title, desc } = req.body;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 800,
        system: TEACH_SYSTEM,
        messages: [{ role: "user", content: `Topik: ${title}. Konteks: ${desc}` }],
      }),
    });
    const data = await r.json();
    const text = data?.content?.map((c) => c.text || "").join("\n") || "";
    res.status(200).json({ explanation: text });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "teach_failed" });
  }
}
