import { getSession } from "../../../lib/session";

async function classroomFetch(path, accessToken) {
  const r = await fetch(`https://classroom.googleapis.com/v1${path}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!r.ok) {
    const errBody = await r.text();
    throw new Error(`Classroom API error ${r.status}: ${errBody}`);
  }
  return r.json();
}

export default async function handler(req, res) {
  const session = getSession(req);
  if (!session) {
    return res.status(401).json({ error: "not_authenticated" });
  }

  try {
    const coursesData = await classroomFetch("/courses?courseStates=ACTIVE", session.access_token);
    const courses = coursesData.courses || [];

    // Ambil coursework (tugas) untuk tiap kelas, lalu gabungkan
    const assignments = [];
    for (const course of courses) {
      try {
        const cwData = await classroomFetch(
          `/courses/${course.id}/courseWork?courseWorkStates=PUBLISHED`,
          session.access_token
        );
        for (const cw of cwData.courseWork || []) {
          assignments.push({
            id: cw.id,
            classId: course.id,
            className: course.name,
            title: cw.title,
            desc: cw.description || "",
            due: cw.dueDate
              ? new Date(
                  cw.dueDate.year,
                  cw.dueDate.month - 1,
                  cw.dueDate.day,
                  cw.dueTime?.hours || 23,
                  cw.dueTime?.minutes || 59
                ).toISOString()
              : null,
            link: cw.alternateLink,
          });
        }
      } catch (innerErr) {
        console.error(`Gagal ambil coursework untuk ${course.name}:`, innerErr.message);
      }
    }

    res.status(200).json({ courses, assignments });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "classroom_fetch_failed", detail: e.message });
  }
}
