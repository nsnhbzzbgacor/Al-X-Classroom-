import { useState, useEffect, useRef } from "react";
import { BookOpen, Clock, MessageCircle, Send, PinIcon, AlertTriangle, CheckCircle2, GraduationCap, LogOut } from "lucide-react";
import { getSession } from "../lib/session";

export async function getServerSideProps({ req }) {
  const session = getSession(req);
  return { props: { isLoggedIn: !!session } };
}

function daysLeftLabel(dueIso) {
  if (!dueIso) return { text: "Tanpa deadline", urgent: false };
  const due = new Date(dueIso);
  const diff = Math.ceil((due - new Date()) / (1000 * 60 * 60 * 24));
  if (diff < 0) return { text: "Sudah lewat", urgent: true };
  if (diff === 0) return { text: "Hari ini", urgent: true };
  if (diff === 1) return { text: "Besok", urgent: true };
  return { text: `${diff} hari lagi`, urgent: diff <= 2 };
}

function StatusStamp({ status }) {
  const map = {
    belum: { text: "BELUM DIKERJAKAN", color: "#D46A5E" },
    selesai: { text: "SUDAH DIKUMPULKAN", color: "#5C8A6E" },
  };
  const s = map[status] || map.belum;
  return (
    <div style={{ border: `2px solid ${s.color}`, color: s.color, transform: "rotate(-4deg)", fontWeight: 800, fontSize: "10px", letterSpacing: "0.06em", padding: "3px 8px", borderRadius: "4px", display: "inline-block", opacity: 0.85 }}>
      {s.text}
    </div>
  );
}

function AssignmentCard({ a, onMarkDone }) {
  const dl = daysLeftLabel(a.due);
  return (
    <div style={{ background: "#FAF7EF", borderRadius: "3px", padding: "16px 18px", boxShadow: "0 6px 14px rgba(0,0,0,0.25)", position: "relative", marginBottom: "18px" }}>
      <div style={{ position: "absolute", top: "-9px", left: "20px", width: "16px", height: "16px", borderRadius: "50%", background: "#E8C468", boxShadow: "0 2px 3px rgba(0,0,0,0.4)" }} />
      <div style={{ fontSize: "11px", color: "#8A8474", fontFamily: "'Courier New', monospace", marginBottom: "4px" }}>{a.className}</div>
      <div style={{ fontFamily: "Georgia, serif", fontSize: "18px", color: "#2A2A26", fontWeight: 700, marginBottom: "6px" }}>{a.title}</div>
      {a.desc && <div style={{ fontSize: "13px", color: "#5A564C", lineHeight: 1.5, marginBottom: "10px" }}>{a.desc}</div>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <StatusStamp status={a.status} />
        <div style={{ fontFamily: "'Courier New', monospace", fontSize: "12px", fontWeight: 700, color: dl.urgent && a.status === "belum" ? "#D46A5E" : "#5A564C", display: "flex", alignItems: "center", gap: "4px" }}>
          <Clock size={13} />
          {dl.text}
        </div>
      </div>
      {a.link && (
        <a href={a.link} target="_blank" rel="noreferrer" style={{ display: "block", marginTop: "10px", fontSize: "12px", color: "#3E6B57", textAlign: "center" }}>
          Buka di Google Classroom ↗
        </a>
      )}
      {a.status === "belum" && (
        <button onClick={() => onMarkDone(a.id)} style={{ marginTop: "10px", width: "100%", background: "transparent", border: "1.5px dashed #8A8474", borderRadius: "6px", padding: "8px", fontSize: "12px", color: "#5A564C", cursor: "pointer" }}>
          Tandai sudah dikumpulkan (lokal)
        </button>
      )}
    </div>
  );
}

function TugasTab({ assignments, onMarkDone, loading, error }) {
  if (loading) return <div style={{ color: "#D8D4C8", fontSize: "13px", textAlign: "center", padding: "40px 0" }}>Memuat tugas dari Classroom...</div>;
  if (error) return <div style={{ color: "#E8B39A", fontSize: "13px", textAlign: "center", padding: "40px 0" }}>Gagal memuat tugas: {error}</div>;
  if (assignments.length === 0) return <div style={{ color: "#D8D4C8", fontSize: "13px", textAlign: "center", padding: "40px 0" }}>Belum ada tugas ditemukan.</div>;

  const urgent = assignments.filter((a) => a.status === "belum" && daysLeftLabel(a.due).urgent);
  const sorted = [...assignments].sort((a, b) => new Date(a.due || 0) - new Date(b.due || 0));

  return (
    <div>
      {urgent.length > 0 && (
        <div style={{ background: "#3A2620", border: "1px solid #D46A5E", borderRadius: "4px", padding: "12px 16px", marginBottom: "20px", display: "flex", alignItems: "center", gap: "10px" }}>
          <AlertTriangle size={18} color="#E8B39A" />
          <div style={{ color: "#F0EDE4", fontSize: "13px" }}>
            <strong>{urgent.length} tugas</strong> mendekati deadline — cek sebelum kelewatan.
          </div>
        </div>
      )}
      {sorted.map((a) => (
        <AssignmentCard key={a.id} a={a} onMarkDone={onMarkDone} />
      ))}
    </div>
  );
}

function QuizBlock({ assignment, onPass }) {
  const [state, setState] = useState({ loading: true, questions: null, selected: [], result: null, teaching: null });

  useEffect(() => {
    loadQuiz();
    // eslint-disable-next-line
  }, [assignment.id]);

  async function loadQuiz() {
    setState({ loading: true, questions: null, selected: [], result: null, teaching: null });
    try {
      const r = await fetch("/api/assistant/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: assignment.title, desc: assignment.desc }),
      });
      const parsed = await r.json();
      setState({ loading: false, questions: parsed.questions, selected: Array(parsed.questions.length).fill(null), result: null, teaching: null });
    } catch (e) {
      setState({ loading: false, questions: null, selected: [], result: "error", teaching: null });
    }
  }

  function choose(qIdx, optIdx) {
    setState((s) => {
      const sel = [...s.selected];
      sel[qIdx] = optIdx;
      return { ...s, selected: sel };
    });
  }

  async function submit() {
    const correct = state.questions.reduce((acc, q, i) => acc + (state.selected[i] === q.correctIndex ? 1 : 0), 0);
    if (correct >= 2) {
      onPass();
    } else {
      setState((s) => ({ ...s, result: "gagal", teaching: "loading" }));
      const r = await fetch("/api/assistant/teach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: assignment.title, desc: assignment.desc }),
      });
      const data = await r.json();
      setState((s) => ({ ...s, teaching: data.explanation }));
    }
  }

  if (state.loading) return <div style={{ color: "#D8D4C8", fontSize: "13px" }}>Menyiapkan cek pemahaman...</div>;
  if (state.result === "error") {
    return (
      <div style={{ color: "#E8B39A", fontSize: "13px" }}>
        Gagal memuat soal.{" "}
        <button onClick={loadQuiz} style={{ color: "#E8C468", background: "none", border: "none", cursor: "pointer", textDecoration: "underline" }}>Coba lagi</button>
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: "8px", color: "#F0EDE4", fontFamily: "Georgia, serif", fontSize: "16px", fontWeight: 700, marginBottom: "6px" }}>
        <GraduationCap size={18} color="#E8C468" /> Cek pemahaman dulu
      </div>
      <div style={{ color: "#B8C4BC", fontSize: "12.5px", marginBottom: "14px" }}>Jawab benar minimal 2 dari 3 untuk membuka asisten di tugas ini.</div>

      {state.questions.map((q, qi) => (
        <div key={qi} style={{ background: "#FAF7EF", borderRadius: "6px", padding: "12px 14px", marginBottom: "10px" }}>
          <div style={{ fontSize: "13.5px", fontWeight: 700, color: "#2A2A26", marginBottom: "8px" }}>{qi + 1}. {q.question}</div>
          {q.options.map((opt, oi) => (
            <label key={oi} style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "13px", color: "#3A3630", padding: "4px 0", cursor: "pointer" }}>
              <input type="radio" name={`q-${qi}`} checked={state.selected[qi] === oi} onChange={() => choose(qi, oi)} />
              {opt}
            </label>
          ))}
        </div>
      ))}

      {state.result !== "gagal" && (
        <button onClick={submit} disabled={state.selected.some((s) => s === null)} style={{ width: "100%", background: state.selected.some((s) => s === null) ? "#6B6656" : "#E8C468", border: "none", borderRadius: "6px", padding: "10px", fontWeight: 700, fontSize: "13px", color: "#2A2A26", cursor: state.selected.some((s) => s === null) ? "not-allowed" : "pointer" }}>
          Kirim jawaban
        </button>
      )}

      {state.result === "gagal" && (
        <div style={{ background: "#3A2620", border: "1px solid #D46A5E", borderRadius: "6px", padding: "14px", marginTop: "10px" }}>
          <div style={{ color: "#E8B39A", fontSize: "13px", fontWeight: 700, marginBottom: "8px" }}>Kamu belum belajar ini — yuk pahami dulu:</div>
          {state.teaching === "loading" ? (
            <div style={{ color: "#D8D4C8", fontSize: "12.5px" }}>Menyiapkan penjelasan...</div>
          ) : (
            <>
              <div style={{ color: "#F0EDE4", fontSize: "13px", lineHeight: 1.6, whiteSpace: "pre-wrap", marginBottom: "12px" }}>{state.teaching}</div>
              <button onClick={loadQuiz} style={{ width: "100%", background: "#E8C468", border: "none", borderRadius: "6px", padding: "10px", fontWeight: 700, fontSize: "13px", color: "#2A2A26", cursor: "pointer" }}>
                Coba cek pemahaman lagi
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function ChatBlock({ assignment, messages, setMessages }) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;
    const newMessages = [...messages, { role: "user", text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    try {
      const r = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: assignment.title, desc: assignment.desc, messages: newMessages }),
      });
      const data = await r.json();
      setMessages((prev) => [...prev, { role: "assistant", text: data.reply }]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", text: "Ada gangguan koneksi. Coba lagi ya." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "440px" }}>
      <div style={{ flex: 1, overflowY: "auto", paddingRight: "4px", marginBottom: "12px" }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: "10px" }}>
            <div style={{ maxWidth: "80%", background: m.role === "user" ? "#E8C468" : "#FAF7EF", color: "#2A2A26", padding: "10px 14px", borderRadius: "10px", fontSize: "13.5px", lineHeight: 1.5, whiteSpace: "pre-wrap", boxShadow: "0 2px 6px rgba(0,0,0,0.2)" }}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && <div style={{ color: "#B8B4A8", fontSize: "12px" }}>mengetik...</div>}
        <div ref={endRef} />
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Tanya soal materi, minta kerangka, dll..."
          style={{ flex: 1, background: "#FAF7EF", border: "1px solid #8A8474", borderRadius: "6px", padding: "10px 12px", fontSize: "13.5px", color: "#2A2A26" }}
        />
        <button onClick={sendMessage} style={{ background: "#E8C468", border: "none", borderRadius: "6px", padding: "0 16px", cursor: "pointer", display: "flex", alignItems: "center" }}>
          <Send size={16} color="#2A2A26" />
        </button>
      </div>
    </div>
  );
}

function AsistenTab({ assignments, assistantState, setAssistantState }) {
  const selectable = assignments.filter((a) => a.status === "belum");
  const [selectedId, setSelectedId] = useState(selectable[0]?.id || null);

  useEffect(() => {
    if (!selectedId && selectable[0]) setSelectedId(selectable[0].id);
  }, [selectable, selectedId]);

  const assignment = assignments.find((a) => a.id === selectedId);
  const st = selectedId ? assistantState[selectedId] : null;

  function handlePass() {
    setAssistantState((prev) => ({
      ...prev,
      [selectedId]: {
        access: "unlocked",
        messages: [{ role: "assistant", text: `Mantap, kamu sudah paham konsep dasarnya! Sekarang ceritain, bagian mana dari "${assignment.title}" yang mau dibahas?` }],
      },
    }));
  }

  if (selectable.length === 0) {
    return <div style={{ color: "#D8D4C8", fontSize: "13px", textAlign: "center", padding: "40px 0" }}>Semua tugas sudah selesai. Belum ada tugas baru untuk dibahas.</div>;
  }

  return (
    <div>
      <select
        value={selectedId || ""}
        onChange={(e) => setSelectedId(e.target.value)}
        style={{ width: "100%", background: "#FAF7EF", border: "1px solid #8A8474", borderRadius: "6px", padding: "10px 12px", fontSize: "13px", color: "#2A2A26", marginBottom: "16px" }}
      >
        {selectable.map((a) => (
          <option key={a.id} value={a.id}>{a.title}</option>
        ))}
      </select>

      {assignment && st?.access === "locked" && <QuizBlock assignment={assignment} onPass={handlePass} />}

      {assignment && st?.access === "unlocked" && (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: "6px", color: "#8FD4A8", fontSize: "12px", marginBottom: "10px" }}>
            <CheckCircle2 size={14} /> Terbuka untuk "{assignment.title}"
          </div>
          <ChatBlock
            assignment={assignment}
            messages={st.messages}
            setMessages={(msgsOrFn) =>
              setAssistantState((prev) => ({
                ...prev,
                [selectedId]: { ...prev[selectedId], messages: typeof msgsOrFn === "function" ? msgsOrFn(prev[selectedId].messages) : msgsOrFn },
              }))
            }
          />
        </>
      )}
    </div>
  );
}

export default function Home({ isLoggedIn }) {
  const [tab, setTab] = useState("tugas");
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [assistantState, setAssistantState] = useState({});

  useEffect(() => {
    if (!isLoggedIn) {
      setLoading(false);
      return;
    }
    fetch("/api/classroom/courses")
      .then((r) => r.json())
      .then((data) => {
        if (data.error) throw new Error(data.detail || data.error);
        const withStatus = data.assignments.map((a) => ({ ...a, status: "belum" }));
        setAssignments(withStatus);
        const initState = {};
        withStatus.forEach((a) => (initState[a.id] = { access: "locked", messages: [] }));
        setAssistantState(initState);
        setLoading(false);
      })
      .catch((e) => {
        setError(e.message);
        setLoading(false);
      });
  }, [isLoggedIn]);

  function markDone(id) {
    setAssignments((prev) => prev.map((a) => (a.id === id ? { ...a, status: "selesai" } : a)));
    setAssistantState((prev) => ({ ...prev, [id]: { access: "closed", messages: [] } }));
  }

  return (
    <div style={{ minHeight: "100vh", padding: "0 0 40px" }}>
      <div style={{ maxWidth: "480px", margin: "0 auto", padding: "24px 16px" }}>
        <div style={{ marginBottom: "22px", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 700, fontSize: "26px", color: "#F0EDE4", letterSpacing: "0.02em", borderBottom: "2px dashed #6B8A7E", paddingBottom: "10px", display: "flex", alignItems: "center", gap: "8px" }}>
              <PinIcon size={20} color="#E8C468" /> Ruang Kelas
            </div>
            <div style={{ color: "#A8C4B4", fontSize: "12.5px", marginTop: "8px" }}>Pantau tugas & belajar dibantu, bukan digantikan.</div>
          </div>
          {isLoggedIn && (
            <a href="/api/auth/logout" style={{ color: "#D8D4C8", fontSize: "12px", display: "flex", alignItems: "center", gap: "4px" }}>
              <LogOut size={14} /> Keluar
            </a>
          )}
        </div>

        {!isLoggedIn ? (
          <div style={{ background: "#FAF7EF", borderRadius: "8px", padding: "24px", textAlign: "center" }}>
            <div style={{ fontFamily: "Georgia, serif", fontSize: "17px", fontWeight: 700, marginBottom: "10px", color: "#2A2A26" }}>Masuk dengan Google Classroom</div>
            <div style={{ fontSize: "13px", color: "#5A564C", marginBottom: "16px" }}>Kami hanya membaca daftar kelas & tugasmu, tidak mengubah apa pun.</div>
            <a href="/api/auth/login" style={{ display: "inline-block", background: "#E8C468", color: "#2A2A26", fontWeight: 700, padding: "10px 20px", borderRadius: "6px", textDecoration: "none", fontSize: "13px" }}>
              Masuk dengan Google
            </a>
          </div>
        ) : (
          <>
            <div style={{ display: "flex", gap: "8px", marginBottom: "20px" }}>
              {[{ id: "tugas", label: "Tugas", icon: BookOpen }, { id: "asisten", label: "Asisten Belajar", icon: MessageCircle }].map((t) => {
                const Icon = t.icon;
                const active = tab === t.id;
                return (
                  <button key={t.id} onClick={() => setTab(t.id)} style={{ flex: 1, background: active ? "#E8C468" : "transparent", color: active ? "#2A2A26" : "#D8D4C8", border: `1px solid ${active ? "#E8C468" : "#5C7A6E"}`, borderRadius: "6px", padding: "10px", fontSize: "13px", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }}>
                    <Icon size={15} /> {t.label}
                  </button>
                );
              })}
            </div>

            {tab === "tugas" ? (
              <TugasTab assignments={assignments} onMarkDone={markDone} loading={loading} error={error} />
            ) : (
              <AsistenTab assignments={assignments} assistantState={assistantState} setAssistantState={setAssistantState} />
            )}
          </>
        )}
      </div>
    </div>
  );
}
