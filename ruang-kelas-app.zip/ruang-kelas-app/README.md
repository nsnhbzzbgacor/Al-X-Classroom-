# Ruang Kelas — Classroom Tracker + Asisten Belajar

## Apa isinya
- **Tab Tugas**: narik daftar tugas asli dari Google Classroom kamu.
- **Tab Asisten Belajar**: tiap tugas dikunci sampai lulus cek pemahaman konsep dasar (3 soal). Kalau gagal, AI ngajarin konsepnya dulu. Kalau lulus, chat kebuka tapi dibatasi supaya AI cuma bantu (bukan ngerjain final answer). Tugas yang ditandai selesai otomatis mengunci lagi chat-nya.

## 1. Coba di komputer sendiri dulu (opsional tapi disarankan)

Butuh Node.js versi 18 ke atas. Cek dulu: `node -v`

```bash
npm install
cp .env.local.example .env.local
```

Buka file `.env.local`, isi 4 nilainya:
- `ANTHROPIC_API_KEY` — dari console.anthropic.com → API Keys
- `GOOGLE_CLIENT_ID` dan `GOOGLE_CLIENT_SECRET` — dari console.cloud.google.com → Credentials
- `APP_BASE_URL` — biarkan `http://localhost:3000` untuk coba lokal
- `SESSION_SECRET` — ketik teks acak apa saja, sepanjang mungkin

Jalankan:
```bash
npm run dev
```
Buka `http://localhost:3000` di browser.

**Penting**: di Google Cloud Console → Credentials → OAuth client ID kamu, pastikan `http://localhost:3000/api/auth/callback` sudah ada di daftar Authorized redirect URIs.

## 2. Deploy supaya bisa dibuka publik (pakai Vercel, gratis)

1. Bikin akun di [vercel.com](https://vercel.com) (bisa login pakai GitHub)
2. Upload folder project ini ke GitHub:
   - Bikin repo baru di [github.com/new](https://github.com/new)
   - Upload semua file di folder ini ke repo itu (drag & drop lewat web GitHub juga bisa)
   - **Pastikan file `.env.local` TIDAK ikut ke-upload** (sudah otomatis diabaikan lewat `.gitignore`)
3. Di Vercel, klik **Add New → Project**, pilih repo GitHub yang tadi
4. Sebelum klik Deploy, buka bagian **Environment Variables**, isi 4 nilai yang sama seperti di `.env.local`, tapi `APP_BASE_URL` diisi nanti setelah tahu domain Vercel-nya (bisa diisi sementara, diedit lagi setelah deploy pertama)
5. Klik **Deploy**
6. Setelah selesai, kamu dapat URL seperti `https://nama-app.vercel.app`
7. Balik ke Environment Variables di Vercel, update `APP_BASE_URL` jadi URL itu, lalu **Redeploy**
8. Balik ke Google Cloud Console → Credentials → OAuth client ID, **tambahkan** `https://nama-app.vercel.app/api/auth/callback` ke Authorized redirect URIs (jangan hapus yang localhost, biarkan saja)

Setelah itu, link `https://nama-app.vercel.app` sudah bisa dibuka siapa saja dan mereka login pakai akun Google Classroom masing-masing.

## Catatan tentang OAuth consent screen ("unverified app")

Karena app ini belum diverifikasi Google, pas login akan muncul peringatan "Google hasn't verified this app". Ini normal untuk app pribadi/skala kecil. Kalau OAuth consent screen kamu masih mode **Testing**, hanya email yang kamu daftarkan sebagai "Test user" di Google Cloud Console yang bisa login. Untuk dipakai banyak orang, perlu ganti status ke **Production** (tetap akan ada peringatan unverified kecuali diajukan verifikasi ke Google, yang butuh waktu review).

## Biaya
- Vercel: gratis untuk pemakaian skala kecil/pribadi.
- Google Cloud: Classroom API gratis dipakai, tidak butuh billing aktif untuk OAuth.
- Anthropic API: dikenakan biaya per pemakaian (bayar sesuai jumlah pesan). Cek harga terbaru di console.anthropic.com.
